#include "appl.h"

int main(int argc, char* argv[]) {
	draw_application app;
	app.run(argc, argv);
}