#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include <limits.h>
#define MAX 100

/* --------- longest increasing subsequence --------- */
int longest_increasing_subsequence (int const s [], int const n);
