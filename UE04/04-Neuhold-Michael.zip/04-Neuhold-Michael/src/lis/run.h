/* --------- longest increasing run --------- */
int longest_increasing_run (int const s [], int const n);