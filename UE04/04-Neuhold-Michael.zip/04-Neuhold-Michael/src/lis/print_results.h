#include <limits.h>

/* --------- print result functions --------- */
void print_line();
void print_header(char msg[]);
void print_table_row(int a[], int n);
void print_result(int s[], int l[], int p[], int n);

/* --------- Test Function --------- */
void Testing(int seq[], int n);