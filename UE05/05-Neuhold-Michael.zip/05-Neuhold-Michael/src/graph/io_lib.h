//
// Created by Michael Neuhold on 09.11.19.
//

#ifndef GRAPHS_IO_LIB_H
#define GRAPHS_IO_LIB_H

#include <stdio.h>

void print_line();

#endif //GRAPHS_IO_LIB_H
