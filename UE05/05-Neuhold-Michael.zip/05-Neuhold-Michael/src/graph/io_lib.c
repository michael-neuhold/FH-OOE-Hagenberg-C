//
// Created by Michael Neuhold on 09.11.19.
//

#include "io_lib.h"

void print_line() {
    for (int i = 0; i < 50; i++) {
        printf("-");
    }
    printf("\n");
}